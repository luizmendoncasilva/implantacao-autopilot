/*
  Tela da Convenção Coletiva — parametrização vinculada obrigatoriamente a um
  Sindicato (Partes II e III da especificação). Página única com 6 abas
  (client-side, sem navegar de arquivo — padrão de parametros-fiscais-arquitetura.md
  §13, adaptado; ver especificação de UX §8). Edição é global: "Editar" abre
  todas as abas para edição de uma vez; "Gravar"/"Cancelar" se aplicam ao
  registro inteiro, no mesmo padrão de alternância view/edit já usado na Tela
  do Sindicato.
*/
(function () {
  const D = window.SindicatosData;
  const E = window.EmpresasData;

  const codigoConvencao = D.getQueryParam("convencao");
  const codigoSindicatoParam = D.getQueryParam("sindicato");
  const convencaoExistente = codigoConvencao ? D.findConvencaoByCodigo(codigoConvencao) : null;

  if (codigoConvencao && !convencaoExistente) {
    window.location.replace("index.html");
    return;
  }

  const sindicatoVinculado = convencaoExistente
    ? D.findSindicatoByCodigo(convencaoExistente.sindicatoCodigo)
    : D.findSindicatoByCodigo(codigoSindicatoParam);

  if (!sindicatoVinculado) {
    window.location.replace("index.html");
    return;
  }

  const isNovo = !convencaoExistente;

  function blankConvencao() {
    return {
      codigo: "", sindicatoCodigo: sindicatoVinculado.codigo, descricao: "",
      configGerais: {
        salarioMesAdmissao: "", calcProporcionalidadeHorista: "", adicionalNoturno: "", horaExtra: "",
        mesesFeriasProporcionais: "", indenizar13FeriasAvisoReavido: "",
        descontarDSRFaltaIntegral: { ativo: false, proporcao: "" }, calcularDSRProfessorMensalista: false,
        calcularSalarioProporcionalDias: "", regrasDiasReais: { semEventos: false, comAfastamento: false, comFerias: false, rescisao: false, admissao: false, divisor: false },
      },
      dataBasePrazos: {
        dataBase: "", calcularDiferencaContribAssistencial: false, diasAusenciaAbonados: { ativo: false, dias: "" },
        percentualMaxVT: "", limiteCargaHoraria: { ativo: false, min: "", max: "" }, diasIndenizacaoDataBase: "",
        naoPagarIndenizacaoAposDataLimite: "", diasAssistenciaHomologacao: "", diasPagamentoRescisao: "", formaApuracaoDias: "", regrasContratoExperiencia: false,
      },
      contribuicoes: {
        assistencial: { ativa: false, mesFolha: "", formaFolha: "", diasFolha: "", mes13: "", forma13: "", dias13: "", descontoAdmissaoPercentual: "", semDescontarEmpregado: false },
        associativa: { ativa: false, mesFolha: "", formaFolha: "", diasFolha: "", mes13: "", forma13: "", dias13: "" },
        confederativa: { ativa: false, mesFolha: "", formaFolha: "", diasFolha: "", mes13: "", forma13: "", dias13: "", naoCumular: false },
        sindical: { ativa: false, mes: "", forma: "", diasTotal: "" },
        mesContribuicaoSindicalAnual: "", gradeConfiguracaoContribAssistencial: [],
      },
      empresasVinculadas: [], pisoSalarial: [], historico: [],
      condicionais: {
        calculos: {
          ferias: { pagarAvosAfastamento180: false, novoPeriodoAquisitivoColetivas: false, adiantar13Ferias: false, fracaoMinimaAvos: { ativo: false, dias: "" }, gratificacaoFerias: { ativo: false } },
          decimoTerceiro: { avosLimitadosAfastamento: { ativo: false, dias: "" }, maiorGradeProfessor: false, reaproveitarUltimoValorAdicional: false },
          avisoPrevio: { avisoMisto: false, tratamentoLei12506: "", liminarInssAvisoIndenizado: false, suspensaoFeriasColetivas: false },
          garantiaSemestral: { aplicacaoProfessorAulista: false },
          licencaPremio: { possui: false, pagarMediaAdicional: false, indenizarNaoGozados: false },
          resilicaoProfessor: { calcular13ReducaoGrade: false, calcularFeriasReducaoGrade: false },
          adicionalTempoServico: { possuiGrade: false, grade: [] },
        },
        comissionado: { pagar13ProporcionalEntreRegimes: false, possuiGarantiaMinima: false },
        medias: { considerarMaisFavoravel: false, mediasDiferenciadasModalidade13: false, reaproveitamentoMediaFerias: false, mediaDiferenciadaComissoes: false, formaCalculoMedia: "" },
        estabilidade: { extensaoAposFerias: false, projecaoAvisoPrevioIndenizado: false, dilatacaoFeriasGozadas: false },
        indenizacaoEspecial: { possuiRescisao: false, possuiAfastamento: false },
        plr: { proporcionalidadeMesesTrabalhados: false, regraMesCheio: false, plrNaRescisao: false, projecaoAvisoPrevio: false },
        observacoes: "",
      },
    };
  }

  let mode = isNovo ? "create" : "view";
  let form = isNovo ? blankConvencao() : JSON.parse(JSON.stringify(convencaoExistente));
  const state = {
    tab: "geral",
    accordionOpen: { calculos: false, comissionado: false, medias: false, estabilidade: false, indenizacaoEspecial: false, plr: false, observacoes: false },
  };

  function getPath(obj, path) {
    return path.split(".").reduce((o, k) => (o == null ? o : o[k]), obj);
  }
  function setPath(obj, path, value) {
    const keys = path.split(".");
    let o = obj;
    for (let i = 0; i < keys.length - 1; i++) o = o[keys[i]];
    o[keys[keys.length - 1]] = value;
  }

  function ensureToast() {
    if (document.getElementById("toast")) return;
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.id = "toast";
    toast.innerHTML = '<span class="toast-icon"></span><div class="flex flex-col gap-0-5"><span class="toast-title"></span><span class="toast-desc"></span></div>';
    document.body.appendChild(toast);
  }

  // ===== Helpers de campo (view + edit) =====
  function campoView(label, valueHtml, wide) {
    return '<div class="detail-field' + (wide ? " detail-field-wide" : "") + '"><span class="detail-field-label">' + label + '</span><div class="detail-field-value">' + valueHtml + "</div></div>";
  }
  function campoEdit(label, inputHtml, wide, obrigatorio) {
    return '<div class="detail-field' + (wide ? " detail-field-wide" : "") + '"><span class="detail-field-label">' + label + (obrigatorio ? ' <span class="text-muted">*</span>' : "") + "</span>" + inputHtml + "</div>";
  }
  function vazio() { return '<span class="italic text-muted">—</span>'; }

  function optLabel(options, value) {
    const found = (options || []).find((o) => (o.value || o) === value);
    return found ? found.label || found : value;
  }
  function textField(label, path, opts) {
    opts = opts || {};
    const value = getPath(form, path);
    if (mode === "view") return campoView(label, value ? value : vazio(), opts.wide);
    return campoEdit(label, '<input class="field-input" data-path="' + path + '" value="' + (value || "").replace(/"/g, "&quot;") + '" placeholder="' + (opts.placeholder || "") + '" />', opts.wide, opts.obrigatorio);
  }
  function selectField(label, path, options, opts) {
    opts = opts || {};
    const value = getPath(form, path);
    if (mode === "view") return campoView(label, value ? optLabel(options, value) : vazio(), opts.wide);
    const optsHtml = options
      .map((o) => {
        const v = o.value !== undefined ? o.value : o;
        const l = o.label !== undefined ? o.label : o;
        return '<option value="' + v + '"' + (value === v ? " selected" : "") + ">" + l + "</option>";
      })
      .join("");
    return campoEdit(
      label,
      '<div class="field-select-wrap"><select class="field-select" data-path="' + path + '"><option value="">Selecione...</option>' + optsHtml + "</select><span class=\"chev\">" + Icon("chevron-down", "size-4") + "</span></div>",
      opts.wide,
      opts.obrigatorio
    );
  }
  function checkboxField(path, label, hint) {
    const checked = !!getPath(form, path);
    if (mode === "view") {
      return '<div class="flex items-center gap-2 text-sm">' + (checked ? '<span style="color:var(--success-text);display:flex;">' + Icon("circle-check", "size-4") + "</span>" : '<span class="text-muted">' + Icon("circle-x", "size-4") + "</span>") + "<span" + (checked ? "" : ' class="text-muted"') + ">" + label + "</span></div>";
    }
    return '<label class="ucheckbox" data-path="' + path + '"><span class="ucheckbox-box' + (checked ? " is-checked" : "") + '">' + Icon("check", "size-4") + '</span><span class="ucheckbox-label">' + label + (hint ? '<span class="ucheckbox-hint">' + hint + "</span>" : "") + "</span></label>";
  }
  function refList(items) {
    if (!items.length) return "";
    return (
      '<div class="flex flex-col" style="margin-top:6px;"><span class="text-xs text-muted uppercase tracking-wide" style="margin-bottom:4px;">Demais parâmetros desta categoria (referência da especificação)</span>' +
      items
        .map(
          ([label, tipo]) =>
            '<div class="flex items-center justify-between gap-3" style="padding:7px 0;border-top:1px solid var(--border);"><span class="text-xs">' + label + '</span><span class="badge badge-outline">' + tipo + "</span></div>"
        )
        .join("") +
      "</div>"
    );
  }
  function secao(titulo, camposHtml) {
    return '<div class="detail-section"><h3 class="detail-section-title">' + titulo + '</h3><div class="detail-grid">' + camposHtml + "</div></div>";
  }

  // ===== Aba 1: Configurações Gerais de Cálculo =====
  function tabConfigGerais() {
    const cg = form.configGerais;
    const O = D.CONFIG_GERAIS_OPCOES;
    let html = secao(
      "Cálculo do salário e proporcionalidade",
      selectField("Salário mês admissão", "configGerais.salarioMesAdmissao", O.salarioMesAdmissao, { obrigatorio: true }) +
        selectField("Cálculo proporcionalidade para Horista", "configGerais.calcProporcionalidadeHorista", O.calcProporcionalidadeHorista, {}) +
        textField("Adicional noturno (%)", "configGerais.adicionalNoturno", { placeholder: "20,00", obrigatorio: true }) +
        textField("Hora extra (%)", "configGerais.horaExtra", { placeholder: "50,00", obrigatorio: true }) +
        selectField("Meses férias proporcionais", "configGerais.mesesFeriasProporcionais", O.mesesFeriasProporcionais, { obrigatorio: true }) +
        selectField("Indenizar 13º/férias no aviso reavido", "configGerais.indenizar13FeriasAvisoReavido", O.simNao, { obrigatorio: true }) +
        selectField("Calcular salário proporcional aos dias do mês", "configGerais.calcularSalarioProporcionalDias", O.simNao, { obrigatorio: true })
    );

    let dsrHtml = checkboxField("configGerais.descontarDSRFaltaIntegral.ativo", "Descontar DSR por falta integral");
    if (cg.descontarDSRFaltaIntegral.ativo) {
      dsrHtml += '<div style="margin-top:10px;max-width:220px;">' + selectField("Proporção", "configGerais.descontarDSRFaltaIntegral.proporcao", O.proporcaoDSR, { obrigatorio: true }) + "</div>";
    }
    const dsrProfessorHtml = checkboxField("configGerais.calcularDSRProfessorMensalista", "Calcular DSR professor mensalista (1/6)");

    let diasReaisHtml = "";
    if (cg.calcularSalarioProporcionalDias === "sim") {
      const opcoes = [
        ["semEventos", "Competências sem eventos"],
        ["comAfastamento", "Competências com afastamento"],
        ["comFerias", "Competências com férias"],
        ["rescisao", "Rescisão"],
        ["admissao", "Admissão"],
        ["divisor", "Divisor"],
      ];
      diasReaisHtml =
        '<div class="detail-section"><h3 class="detail-section-title">Regras de aplicação dos dias reais do mês</h3><div class="flex flex-col gap-2">' +
        opcoes.map(([k, l]) => checkboxField("configGerais.regrasDiasReais." + k, l)).join("") +
        "</div></div>";
    }

    html +=
      '<div class="detail-section"><h3 class="detail-section-title">Regras condicionais</h3><div class="flex flex-col gap-4">' +
      '<div>' + dsrHtml + "</div>" +
      '<div>' + dsrProfessorHtml + "</div>" +
      "</div></div>" +
      diasReaisHtml;
    return html;
  }

  // ===== Aba 2: Data-base, Prazos e Regras Gerais =====
  function tabDataBasePrazos() {
    const p = form.dataBasePrazos;
    let html = secao(
      "Data-base e prazos",
      textField("Data-base", "dataBasePrazos.dataBase", { placeholder: "01/12", obrigatorio: true }) +
        textField("Dias para indenização data-base", "dataBasePrazos.diasIndenizacaoDataBase", { obrigatorio: true }) +
        textField("Não pagar indenização data-base após data-limite", "dataBasePrazos.naoPagarIndenizacaoAposDataLimite", { placeholder: "01/12" }) +
        textField("Dias para assistência na homologação", "dataBasePrazos.diasAssistenciaHomologacao", {}) +
        textField("Dias para pagamento da rescisão", "dataBasePrazos.diasPagamentoRescisao", {}) +
        selectField("Forma de apuração dos dias (rescisão)", "dataBasePrazos.formaApuracaoDias", D.FORMA_APURACAO_DIAS_OPCOES, {
          obrigatorio: !!(p.diasAssistenciaHomologacao || p.diasPagamentoRescisao),
        })
    );

    const contribAssistHtml = checkboxField("dataBasePrazos.calcularDiferencaContribAssistencial", "Calcular diferença de Contribuição Assistencial por alteração salarial");
    const experienciaHtml = checkboxField("dataBasePrazos.regrasContratoExperiencia", "Regras para contrato de experiência (art. 479/480 CLT)");

    let ausenciaHtml = checkboxField("dataBasePrazos.diasAusenciaAbonados.ativo", "Dias de ausência justificada abonados pelo sindicato");
    if (p.diasAusenciaAbonados.ativo) {
      ausenciaHtml += '<div style="margin-top:10px;max-width:160px;">' + textField("Quantidade de dias", "dataBasePrazos.diasAusenciaAbonados.dias", { obrigatorio: true }) + "</div>";
    }

    let cargaHtml = checkboxField("dataBasePrazos.limiteCargaHoraria.ativo", "Limite de carga horária mínima/máxima mensal");
    if (p.limiteCargaHoraria.ativo) {
      cargaHtml +=
        '<div class="flex gap-4" style="margin-top:10px;max-width:340px;">' +
        textField("Mínima (horas)", "dataBasePrazos.limiteCargaHoraria.min", { obrigatorio: true }) +
        textField("Máxima (horas)", "dataBasePrazos.limiteCargaHoraria.max", { obrigatorio: true }) +
        "</div>";
    }

    html +=
      '<div class="detail-section"><h3 class="detail-section-title">Regras condicionais</h3><div class="flex flex-col gap-4">' +
      "<div>" + contribAssistHtml + "</div>" +
      "<div>" + ausenciaHtml + "</div>" +
      "<div>" + cargaHtml + "</div>" +
      "<div>" + experienciaHtml + "</div>" +
      "</div></div>" +
      secao("Vale-transporte", textField("Percentual máximo para desconto de VT", "dataBasePrazos.percentualMaxVT", { placeholder: "Preencher só se diferente do padrão geral (6%)" }));
    return html;
  }

  // ===== Aba 3: Contribuições Sindicais =====
  function contribuicaoCard(titulo, path, temNaoCumular) {
    const c = getPath(form, path);
    let html = '<div class="subcard"><div class="subcard-title">' + titulo + "</div>" + checkboxField(path + ".ativa", "Esta contribuição é cobrada por este sindicato");
    if (c.ativa) {
      html +=
        '<div class="detail-grid" style="margin-top:6px;">' +
        selectField("Mês (folha mensal)", path + ".mesFolha", D.MESES_OPCOES) +
        selectField("Forma (folha mensal)", path + ".formaFolha", D.FORMA_CONTRIBUICAO_OPCOES) +
        textField("Dias (folha mensal)", path + ".diasFolha", {}) +
        selectField("Mês (13º salário)", path + ".mes13", D.MESES_OPCOES) +
        selectField("Forma (13º salário)", path + ".forma13", D.FORMA_CONTRIBUICAO_OPCOES) +
        textField("Dias (13º salário)", path + ".dias13", {}) +
        "</div>";
      if (temNaoCumular) html += '<div style="margin-top:6px;">' + checkboxField(path + ".naoCumular", "Não cumular desconto com Assistencial/Sindical na mesma competência") + "</div>";
    }
    html += "</div>";
    return html;
  }

  function tabContribuicoes() {
    const c = form.contribuicoes;
    let assistencialHtml = '<div class="subcard"><div class="subcard-title">Contribuição Assistencial</div>' + checkboxField("contribuicoes.assistencial.ativa", "Esta contribuição é cobrada por este sindicato");
    if (c.assistencial.ativa) {
      assistencialHtml +=
        '<div class="detail-grid" style="margin-top:6px;">' +
        selectField("Mês (folha mensal)", "contribuicoes.assistencial.mesFolha", D.MESES_OPCOES) +
        selectField("Forma (folha mensal)", "contribuicoes.assistencial.formaFolha", D.FORMA_CONTRIBUICAO_OPCOES) +
        textField("Dias (folha mensal)", "contribuicoes.assistencial.diasFolha", {}) +
        selectField("Mês (13º salário)", "contribuicoes.assistencial.mes13", D.MESES_OPCOES) +
        selectField("Forma (13º salário)", "contribuicoes.assistencial.forma13", D.FORMA_CONTRIBUICAO_OPCOES) +
        textField("Dias (13º salário)", "contribuicoes.assistencial.dias13", {}) +
        textField("Desconto (%) na competência de admissão", "contribuicoes.assistencial.descontoAdmissaoPercentual", {}) +
        "</div>" +
        '<div style="margin-top:6px;">' + checkboxField("contribuicoes.assistencial.semDescontarEmpregado", "Calcular sem descontar do empregado (empresa arca com o valor)") + "</div>";
    }
    assistencialHtml += "</div>";

    const gradeRows = c.gradeConfiguracaoContribAssistencial;
    let gradeHtml =
      '<div class="subcard"><div class="flex items-center justify-between gap-3"><div class="subcard-title">Grade de configuração de Contribuição Assistencial</div>' +
      (mode !== "view" ? '<button type="button" class="btn btn-outline btn-sm" id="btn-add-grade-contrib">' + Icon("plus", "size-3-5") + " Adicionar linha</button>" : "") +
      "</div>";
    if (gradeRows.length === 0) {
      gradeHtml += '<div class="row-empty-state">Nenhuma linha configurada.</div>';
    } else {
      gradeHtml +=
        '<div class="table-wrap"><table class="dtable dtable-compact"><thead><tr><th>Faixa salarial</th><th>Percentual</th><th>Valor fixo</th>' + (mode !== "view" ? "<th></th>" : "") + "</tr></thead><tbody>" +
        gradeRows
          .map((r, i) =>
            mode === "view"
              ? "<tr><td>" + r.faixa + "</td><td>" + (r.percentual || "—") + "</td><td>" + (r.valorFixo || "—") + "</td></tr>"
              : "<tr>" +
                '<td><input class="field-input" data-grade-contrib="' + i + '" data-campo="faixa" value="' + r.faixa.replace(/"/g, "&quot;") + '" /></td>' +
                '<td><input class="field-input" data-grade-contrib="' + i + '" data-campo="percentual" value="' + r.percentual + '" /></td>' +
                '<td><input class="field-input" data-grade-contrib="' + i + '" data-campo="valorFixo" value="' + r.valorFixo + '" /></td>' +
                '<td><button type="button" class="btn-link" style="color:var(--destructive);" data-remove-grade-contrib="' + i + '">remover</button></td>' +
                "</tr>"
          )
          .join("") +
        "</tbody></table></div>";
    }
    gradeHtml += "</div>";

    return (
      assistencialHtml +
      contribuicaoCard("Contribuição Associativa", "contribuicoes.associativa", false) +
      contribuicaoCard("Contribuição Confederativa", "contribuicoes.confederativa", true) +
      '<div class="subcard"><div class="subcard-title">Contribuição Sindical</div>' +
      checkboxField("contribuicoes.sindical.ativa", "Esta contribuição é cobrada por este sindicato") +
      (form.contribuicoes.sindical.ativa
        ? '<div class="detail-grid" style="margin-top:6px;">' +
          selectField("Mês", "contribuicoes.sindical.mes", D.MESES_OPCOES) +
          selectField("Forma", "contribuicoes.sindical.forma", D.FORMA_CONTRIBUICAO_OPCOES) +
          textField("Total de dias", "contribuicoes.sindical.diasTotal", {}) +
          "</div>"
        : "") +
      "</div>" +
      '<div class="subcard">' +
      selectField("Mês de contribuição (Contribuição Sindical anual)", "contribuicoes.mesContribuicaoSindicalAnual", D.MESES_OPCOES, { wide: true }) +
      '<span class="text-xs text-muted">Referência ao art. 580 da CLT — observada a exigência de autorização prévia e expressa do empregado.</span>' +
      "</div>" +
      gradeHtml
    );
  }

  // ===== Aba 4: Empresas Vinculadas =====
  function tabEmpresas() {
    const selecionadas = form.empresasVinculadas;
    const alertaHtml =
      selecionadas.length === 0
        ? '<div class="alert alert-warning gap-2">' + Icon("alert-triangle", "size-4") + '<div class="alert-desc">Esta convenção ainda não produz efeito na folha — <b>nenhuma empresa vinculada</b>.</div></div>'
        : '<div class="flex items-center gap-2 text-sm text-muted">' + selecionadas.length + (selecionadas.length === 1 ? " empresa vinculada" : " empresas vinculadas") + "</div>";

    const acoesHtml = mode !== "view"
      ? '<div class="flex gap-2"><button type="button" class="btn btn-outline btn-sm" id="btn-emp-todas">Todas</button><button type="button" class="btn btn-outline btn-sm" id="btn-emp-nenhuma">Nenhuma</button><button type="button" class="btn btn-outline btn-sm" id="btn-emp-inverter">Inverter</button></div>'
      : "";

    const listaEmpresas = mode === "view" ? E.EMPRESAS.filter((e) => selecionadas.includes(e.codigo)) : E.EMPRESAS;

    let tabelaHtml;
    if (listaEmpresas.length === 0) {
      tabelaHtml = '<div class="row-empty-state">Nenhuma empresa vinculada a esta convenção.</div>';
    } else {
      const rows = listaEmpresas
        .map((e) => {
          const marcada = selecionadas.includes(e.codigo);
          return (
            "<tr>" +
            (mode !== "view"
              ? '<td style="width:36px;"><label class="ucheckbox" data-empresa-check="' + e.codigo + '"><span class="ucheckbox-box' + (marcada ? " is-checked" : "") + '">' + Icon("check", "size-4") + "</span></label></td>"
              : "") +
            "<td>" + e.nome + "</td>" +
            '<td class="col-pad-md">' + e.dadosGerais.cnpj + "</td>" +
            "</tr>"
          );
        })
        .join("");
      tabelaHtml =
        '<div class="table-wrap"><table class="dtable"><thead><tr>' +
        (mode !== "view" ? "<th></th>" : "") +
        "<th>Empresa</th><th class=\"col-pad-md\">CNPJ</th></tr></thead><tbody>" + rows + "</tbody></table></div>";
    }

    return (
      '<div class="card gap-4"><div class="card-header"><div class="card-title">Empresas vinculadas</div><div class="card-description">Empresas cadastradas no sistema às quais esta convenção se aplica.</div></div>' +
      '<div class="card-content flex flex-col gap-3">' + alertaHtml +
      '<div class="flex items-center justify-between gap-3 flex-wrap">' + acoesHtml + "</div>" +
      tabelaHtml +
      "</div></div>"
    );
  }

  // ===== Aba 5: Piso Salarial e Histórico =====
  function tabPisoHistorico() {
    const pisos = form.pisoSalarial;
    let pisoHtml =
      '<div class="card gap-4"><div class="card-header"><div class="flex items-center justify-between gap-3 flex-wrap">' +
      '<div><div class="card-title">Piso Salarial</div><div class="card-description">Valor mínimo garantido pela convenção, quando houver piso normativo para a categoria.</div></div>' +
      (mode !== "view" ? '<button type="button" class="btn btn-outline btn-sm w-fit" id="btn-add-piso">' + Icon("plus", "size-3-5") + " Adicionar piso</button>" : "") +
      "</div></div><div class=\"card-content\">";
    if (pisos.length === 0) {
      pisoHtml += '<div class="row-empty-state">Nenhum piso salarial cadastrado.</div>';
    } else {
      pisoHtml +=
        '<div class="table-wrap"><table class="dtable"><thead><tr><th>Descrição</th><th class="col-pad-md">Valor</th>' + (mode !== "view" ? '<th class="col-pad-end"></th>' : "") + "</tr></thead><tbody>" +
        pisos
          .map(
            (p) =>
              "<tr><td>" + p.descricao + '</td><td class="col-pad-md">R$ ' + p.valor + "</td>" +
              (mode !== "view"
                ? '<td class="col-pad-end"><div class="flex gap-3"><button type="button" class="btn-link" style="color:var(--info-text);" data-editar-piso="' + p.codigo + '">editar</button><button type="button" class="btn-link" style="color:var(--destructive);" data-remover-piso="' + p.codigo + '">remover</button></div></td>'
                : "") +
              "</tr>"
          )
          .join("") +
        "</tbody></table></div>";
    }
    pisoHtml += "</div></div>";

    const historico = form.historico.slice().sort((a, b) => (a.data < b.data ? 1 : -1));
    let histHtml =
      '<div class="card gap-4"><div class="card-header"><div class="flex items-center justify-between gap-3 flex-wrap">' +
      '<div><div class="card-title">Histórico de Alteração Salarial</div><div class="card-description">Registro cronológico de convenções aplicadas à categoria — origem e percentual de reajuste.</div></div>' +
      (mode !== "view" ? '<button type="button" class="btn btn-outline btn-sm w-fit" id="btn-add-historico">' + Icon("plus", "size-3-5") + " Registrar alteração</button>" : "") +
      "</div></div><div class=\"card-content\">";
    if (historico.length === 0) {
      histHtml += '<div class="row-empty-state">Nenhum histórico de alteração salarial registrado.</div>';
    } else {
      histHtml +=
        '<div class="table-wrap"><table class="dtable"><thead><tr><th>Data</th><th>Descrição</th><th class="col-pad-md">Tipo</th><th class="col-pad-md">Nº processo</th><th class="col-pad-md">% CCT</th>' + (mode !== "view" ? '<th class="col-pad-end"></th>' : "") + "</tr></thead><tbody>" +
        historico
          .map(
            (h) =>
              "<tr><td>" + h.data + "</td><td>" + UI.truncatedCell(h.descricao, 220) + '</td><td class="col-pad-md">' + h.tipo + '</td><td class="col-pad-md">' + (h.numeroProcesso || "—") + '</td><td class="col-pad-md">' + (h.percentualCCT ? h.percentualCCT + "%" : "—") + "</td>" +
              (mode !== "view"
                ? '<td class="col-pad-end"><div class="flex gap-3"><button type="button" class="btn-link" style="color:var(--info-text);" data-editar-historico="' + h.data + '|' + h.descricao.replace(/"/g, "") + '">editar</button><button type="button" class="btn-link" style="color:var(--destructive);" data-remover-historico="' + h.data + '|' + h.descricao.replace(/"/g, "") + '">remover</button></div></td>'
                : "") +
              "</tr>"
          )
          .join("") +
        "</tbody></table></div>";
    }
    histHtml +=
      '<div class="alert alert-info gap-2" style="margin-top:12px;">' + Icon("info", "size-4") +
      '<div class="alert-desc">A especificação chama este registro de "nova vigência da convenção", mas não define se isso deve versionar os demais blocos da parametrização. Neste protótipo, o histórico funciona apenas como um registro cronológico — sem esse efeito. <b>Decisão pendente.</b></div></div>' +
      "</div></div>";

    return pisoHtml + histHtml;
  }

  // ===== Aba 6: Parâmetros Condicionais =====
  function accordionItem(key, titulo, contentHtml) {
    const aberto = state.accordionOpen[key];
    return (
      '<div class="accordion-item' + (aberto ? " is-open" : "") + '">' +
      '<button type="button" class="accordion-trigger" data-accordion-toggle="' + key + '">' +
      '<span class="accordion-trigger-title">' + titulo + "</span>" +
      '<span class="accordion-trigger-chev">' + Icon("chevron-down", "size-4") + "</span>" +
      "</button>" +
      '<div class="accordion-content">' + contentHtml + "</div>" +
      "</div>"
    );
  }

  function subcardFerias() {
    const f = form.condicionais.calculos.ferias;
    let html =
      '<div class="subcard"><div class="subcard-title">Férias</div><div class="flex flex-col gap-2">' +
      checkboxField("condicionais.calculos.ferias.pagarAvosAfastamento180", "Pagar avos com mais de 180 dias de afastamento previdenciário") +
      checkboxField("condicionais.calculos.ferias.novoPeriodoAquisitivoColetivas", "Regras de novo período aquisitivo em férias coletivas") +
      checkboxField("condicionais.calculos.ferias.adiantar13Ferias", "Adiantar 1ª parcela do 13º proporcional nas férias") +
      "</div>";

    html += '<div style="margin-top:4px;">' + checkboxField("condicionais.calculos.ferias.fracaoMinimaAvos.ativo", "Definir fração mínima de dias para avos de férias (demissão/rescisão)");
    if (f.fracaoMinimaAvos.ativo) html += '<div style="margin-top:8px;max-width:160px;">' + textField("Fração mínima (dias)", "condicionais.calculos.ferias.fracaoMinimaAvos.dias", { placeholder: "15", obrigatorio: true }) + "</div>";
    html += "</div>";

    html += '<div style="margin-top:4px;">' + checkboxField("condicionais.calculos.ferias.gratificacaoFerias.ativo", "Gratificação de férias");
    if (f.gratificacaoFerias.ativo) {
      html +=
        '<div class="alert alert-info gap-2" style="margin-top:8px;">' + Icon("info", "size-4") +
        '<div class="alert-desc">Detalhamento previsto na especificação: gozadas/indenizadas, exceções em férias coletivas, não cumulação com 1/3, exclusões por motivo de rescisão. <b>Estrutura de grade pendente de decisão.</b></div></div>';
    }
    html += "</div>";

    html += refList([
      ["Datas de não início de gozo de férias", "Grade/Tabela"],
      ["Adiantamento do 13º nas férias por mês", "Grade/Tabela"],
      ["Maior grade salarial dos últimos meses (professor)", "Checkbox"],
      ["Calcular férias proporcionais para rescisão com justa causa", "Checkbox"],
      ["Definir data de pagamento das férias (dias antes do gozo)", "Número"],
      ["Dias a não considerar nas férias (feriados/pontos facultativos)", "Grade/Tabela"],
      ["Percentual de adicional sobre férias além do 1/3", "Grade/Tabela"],
      ["Dias de gozo diferenciados por condição", "Grade/Tabela"],
    ]);
    html += "</div>";
    return html;
  }

  function subcardDecimoTerceiro() {
    const dt = form.condicionais.calculos.decimoTerceiro;
    let html = '<div class="subcard"><div class="subcard-title">13º Salário</div>';
    html += checkboxField("condicionais.calculos.decimoTerceiro.avosLimitadosAfastamento.ativo", "Limitar avos pagos durante afastamento previdenciário");
    if (dt.avosLimitadosAfastamento.ativo) html += '<div style="margin-top:8px;max-width:160px;">' + textField("Dias-limite / avos", "condicionais.calculos.decimoTerceiro.avosLimitadosAfastamento.dias", { placeholder: "180", obrigatorio: true }) + "</div>";
    html += '<div class="flex flex-col gap-2" style="margin-top:10px;">' +
      checkboxField("condicionais.calculos.decimoTerceiro.maiorGradeProfessor", "Maior grade salarial dos últimos meses (professor)") +
      checkboxField("condicionais.calculos.decimoTerceiro.reaproveitarUltimoValorAdicional", "Reaproveitar último valor de rubricas de adicional no 13º") +
      "</div></div>";
    return html;
  }

  function subcardAvisoPrevio() {
    const ap = form.condicionais.calculos.avisoPrevio;
    let html =
      '<div class="subcard"><div class="subcard-title">Aviso Prévio</div><div class="flex flex-col gap-2">' +
      checkboxField("condicionais.calculos.avisoPrevio.avisoMisto", "Aviso prévio misto (trabalhado/indenizado)") +
      checkboxField("condicionais.calculos.avisoPrevio.liminarInssAvisoIndenizado", "Liminar para não recolhimento de INSS sobre aviso indenizado") +
      checkboxField("condicionais.calculos.avisoPrevio.suspensaoFeriasColetivas", "Suspensão do aviso prévio em férias coletivas") +
      "</div>";
    html += '<div style="margin-top:10px;max-width:340px;">' + selectField("Tratamento dos dias da Lei 12.506/2011", "condicionais.calculos.avisoPrevio.tratamentoLei12506", D.TRATAMENTO_LEI_OPCOES) + "</div>";
    html += refList([
      ["Datas restritas para início do aviso prévio", "Grade/Tabela"],
      ["Base de cálculo do aviso prévio para avos indenizados", "Checkbox"],
      ["Regras de contagem de prazo (notificação, mês completo, sábado/domingo/feriado)", "Seleção múltipla"],
      ["Modalidade padrão de aviso prévio para demissão sem justa causa", "Seleção (lista)"],
      ["Proporcionalidade de dias do aviso (Lei 12.506/2011 ou regra própria)", "Grade/Tabela"],
      ["Redução de jornada/dias durante o aviso trabalhado", "Grade/Tabela"],
      ["Aviso prévio especial", "Grade/Tabela"],
    ]);
    html += "</div>";
    return html;
  }

  function subcardGarantiaSemestral() {
    return (
      '<div class="subcard"><div class="subcard-title">Garantia Semestral</div>' +
      checkboxField("condicionais.calculos.garantiaSemestral.aplicacaoProfessorAulista", "Aplicação a professores aulista variável") +
      refList([["Grade de vigências e condições da garantia semestral", "Grade/Tabela"]]) +
      "</div>"
    );
  }

  function subcardLicencaPremio() {
    const lp = form.condicionais.calculos.licencaPremio;
    let html = '<div class="subcard"><div class="subcard-title">Licença Prêmio</div>' + checkboxField("condicionais.calculos.licencaPremio.possui", "Possui licença prêmio");
    if (lp.possui) {
      html +=
        '<div class="flex flex-col gap-2" style="margin-top:10px;">' +
        checkboxField("condicionais.calculos.licencaPremio.pagarMediaAdicional", "Pagar média/adicional na licença prêmio") +
        checkboxField("condicionais.calculos.licencaPremio.indenizarNaoGozados", "Indenizar na rescisão dias não gozados") +
        "</div>";
    }
    html += "</div>";
    return html;
  }

  function subcardResilicaoProfessor() {
    return (
      '<div class="subcard"><div class="subcard-title">Resilição Professor</div><div class="flex flex-col gap-2">' +
      checkboxField("condicionais.calculos.resilicaoProfessor.calcular13ReducaoGrade", "Calcular 13º proporcional à redução de grade") +
      checkboxField("condicionais.calculos.resilicaoProfessor.calcularFeriasReducaoGrade", "Calcular férias referente à redução de grade") +
      "</div></div>"
    );
  }

  function subcardAdicionalTempoServico() {
    const grade = form.condicionais.calculos.adicionalTempoServico.grade;
    let html =
      '<div class="subcard"><div class="flex items-center justify-between gap-3"><div class="subcard-title">Adicional por Tempo de Serviço</div>' +
      (mode !== "view" ? '<button type="button" class="btn btn-outline btn-sm" id="btn-add-grade-tempo-servico">' + Icon("plus", "size-3-5") + " Adicionar linha</button>" : "") +
      "</div>";
    if (grade.length === 0) {
      html += '<div class="row-empty-state">Nenhuma linha configurada.</div>';
    } else {
      html +=
        '<div class="table-wrap"><table class="dtable dtable-compact"><thead><tr><th>Periodicidade</th><th>Percentual</th><th>Base de cálculo</th>' + (mode !== "view" ? "<th></th>" : "") + "</tr></thead><tbody>" +
        grade
          .map((r, i) =>
            mode === "view"
              ? "<tr><td>" + r.periodicidade + "</td><td>" + r.percentual + "%</td><td>" + r.base + "</td></tr>"
              : "<tr>" +
                '<td><input class="field-input" data-grade-tempo-servico="' + i + '" data-campo="periodicidade" value="' + r.periodicidade.replace(/"/g, "&quot;") + '" /></td>' +
                '<td><input class="field-input" data-grade-tempo-servico="' + i + '" data-campo="percentual" value="' + r.percentual + '" /></td>' +
                '<td><input class="field-input" data-grade-tempo-servico="' + i + '" data-campo="base" value="' + r.base.replace(/"/g, "&quot;") + '" /></td>' +
                '<td><button type="button" class="btn-link" style="color:var(--destructive);" data-remove-grade-tempo-servico="' + i + '">remover</button></td>' +
                "</tr>"
          )
          .join("") +
        "</tbody></table></div>";
    }
    html += "</div>";
    return html;
  }

  function accordionCalculos() {
    return subcardFerias() + subcardDecimoTerceiro() + subcardAvisoPrevio() + subcardGarantiaSemestral() + subcardLicencaPremio() + subcardResilicaoProfessor() + subcardAdicionalTempoServico();
  }

  function accordionComissionado() {
    return (
      '<div class="flex flex-col gap-2">' +
      checkboxField("condicionais.comissionado.pagar13ProporcionalEntreRegimes", "Pagar 13º proporcional entre regimes (Mensalista/Comissionado)") +
      checkboxField("condicionais.comissionado.possuiGarantiaMinima", "Possui garantia mínima")
    ) + (form.condicionais.comissionado.possuiGarantiaMinima
      ? '<div class="alert alert-info gap-2" style="margin-top:10px;">' + Icon("info", "size-4") + '<div class="alert-desc">A especificação não detalha os campos do piso de remuneração garantido. <b>Decisão pendente.</b></div></div>'
      : "") + "</div>";
  }

  function accordionMedias() {
    return (
      '<div class="flex flex-col gap-2">' +
      checkboxField("condicionais.medias.considerarMaisFavoravel", "Considerar a média mais favorável ao empregado") +
      checkboxField("condicionais.medias.mediasDiferenciadasModalidade13", "Médias diferenciadas por modalidade de 13º") +
      checkboxField("condicionais.medias.reaproveitamentoMediaFerias", "Reaproveitamento da média de férias para cálculos seguintes") +
      checkboxField("condicionais.medias.mediaDiferenciadaComissoes", "Média diferenciada para Comissões") +
      "</div>" +
      '<div class="detail-grid" style="margin-top:10px;max-width:340px;">' +
      selectField("Forma de cálculo da média", "condicionais.medias.formaCalculoMedia", D.FORMA_CALCULO_MEDIA_OPCOES, { obrigatorio: true }) +
      "</div>" +
      refList([
        ["Médias diferentes para férias gozadas x pagas em rescisão", "Checkbox"],
        ["Cálculo individual por rubrica", "Checkbox"],
        ["Regras de exclusão do mês de gozo de férias no cálculo de médias", "Checkbox"],
        ["Correção monetária das médias (índice de correção)", "Checkbox + Seleção"],
        ["Regras de médias na rescisão", "Seleção múltipla"],
        ["Regras de médias em afastamento", "Seleção múltipla"],
      ])
    );
  }

  function accordionEstabilidade() {
    return (
      '<div class="flex flex-col gap-2">' +
      checkboxField("condicionais.estabilidade.extensaoAposFerias", "Extensão da estabilidade após retorno de férias") +
      checkboxField("condicionais.estabilidade.projecaoAvisoPrevioIndenizado", "Projeção do aviso prévio indenizado no cálculo da estabilidade") +
      checkboxField("condicionais.estabilidade.dilatacaoFeriasGozadas", "Dilatação da estabilidade por férias gozadas dentro do período") +
      "</div>" +
      refList([
        ["Vínculo de regras de estabilidade a motivo de rescisão", "Grade/Tabela"],
        ["Grade de hipóteses de estabilidade por afastamento", "Grade/Tabela"],
        ["Multa por estabilidade decorrente de dissídio coletivo", "Grade/Tabela"],
        ["Demais estabilidades (CIPA, pré-aposentadoria etc.)", "Grade/Tabela"],
      ])
    );
  }

  function accordionIndenizacaoEspecial() {
    const ie = form.condicionais.indenizacaoEspecial;
    let html = '<div class="flex flex-col gap-2">' + checkboxField("condicionais.indenizacaoEspecial.possuiRescisao", "Indenização especial na rescisão");
    if (ie.possuiRescisao) html += '<span class="text-xs text-muted" style="margin-left:24px;">Grade de indenizações por tempo de casa, faixa salarial ou vínculo — estrutura de colunas pendente de decisão.</span>';
    html += checkboxField("condicionais.indenizacaoEspecial.possuiAfastamento", "Indenização especial em afastamento");
    if (ie.possuiAfastamento) html += '<span class="text-xs text-muted" style="margin-left:24px;">Grade de indenizações por faixa salarial e tipo de folha — estrutura de colunas pendente de decisão.</span>';
    html += "</div>";
    return html;
  }

  function accordionPlr() {
    return (
      '<div class="flex flex-col gap-2">' +
      checkboxField("condicionais.plr.proporcionalidadeMesesTrabalhados", "Proporcionalidade dos meses trabalhados entre vigências") +
      checkboxField("condicionais.plr.regraMesCheio", "Regra de mês cheio (mínimo 15 dias)") +
      checkboxField("condicionais.plr.plrNaRescisao", "PLR na rescisão (antes ou dentro da vigência)") +
      checkboxField("condicionais.plr.projecaoAvisoPrevio", "Projeção do aviso prévio indenizado no cálculo do PLR") +
      "</div>" +
      refList([
        ["Tratamento de afastamentos como tempo trabalhado", "Grade/Tabela"],
        ["Exclusão por motivo de rescisão", "Seleção múltipla"],
        ["Grade de pagamentos do PLR", "Grade/Tabela"],
        ["Grade de descontos sobre o PLR", "Grade/Tabela"],
      ])
    );
  }

  function accordionObservacoes() {
    const valor = form.condicionais.observacoes;
    if (mode === "view") return campoView("Observações", valor || vazio(), true);
    return campoEdit("Observações", '<textarea class="field-textarea" data-path="condicionais.observacoes" placeholder="Particularidades da convenção, contatos, ressalvas...">' + (valor || "") + "</textarea>", true, false);
  }

  function tabCondicionais() {
    return (
      '<div class="accordion">' +
      accordionItem("calculos", "Cálculos", accordionCalculos()) +
      accordionItem("comissionado", "Comissionado", accordionComissionado()) +
      accordionItem("medias", "Médias", accordionMedias()) +
      accordionItem("estabilidade", "Estabilidade", accordionEstabilidade()) +
      accordionItem("indenizacaoEspecial", "Indenização Especial", accordionIndenizacaoEspecial()) +
      accordionItem("plr", "P.L.R.", accordionPlr()) +
      accordionItem("observacoes", "Observações", accordionObservacoes()) +
      "</div>"
    );
  }

  const TABS = [
    { key: "geral", label: "Configurações Gerais de Cálculo", render: tabConfigGerais },
    { key: "databaseprazos", label: "Data-base, Prazos e Regras Gerais", render: tabDataBasePrazos },
    { key: "contribuicoes", label: "Contribuições Sindicais", render: tabContribuicoes },
    { key: "empresas", label: "Empresas Vinculadas", render: tabEmpresas },
    { key: "pisohistorico", label: "Piso Salarial e Histórico", render: tabPisoHistorico },
    { key: "condicionais", label: "Parâmetros Condicionais", render: tabCondicionais },
  ];

  function camposObrigatoriosPreenchidos() {
    return !!(form.descricao || "").trim();
  }

  function render() {
    const podeGravar = camposObrigatoriosPreenchidos();
    const acoesHtml =
      mode === "view"
        ? '<button type="button" class="btn btn-outline btn-sm" id="btn-editar">Editar</button>'
        : '<div class="flex gap-2"><button type="button" class="btn btn-outline btn-sm" id="btn-cancelar">Cancelar</button><button type="button" class="btn btn-sm" id="btn-gravar" ' + (podeGravar ? "" : "disabled") + ">Gravar</button></div>";

    const tituloHtml =
      mode === "view"
        ? '<h2 class="text-lg font-semibold">' + form.descricao + "</h2>"
        : '<input class="field-input" id="input-descricao" style="font-size:17px;font-weight:600;height:44px;max-width:520px;" value="' + form.descricao.replace(/"/g, "&quot;") + '" placeholder="Descrição da convenção *" />';

    const tabsHtml = TABS.map((t) => '<button type="button" class="tabs-trigger' + (t.key === state.tab ? " is-active" : "") + '" data-tab="' + t.key + '">' + t.label + "</button>").join("");

    document.getElementById("convencao-root").innerHTML =
      '<div class="flex flex-col gap-2">' +
      '<a href="sindicato.html?sindicato=' + encodeURIComponent(sindicatoVinculado.codigo) + '" class="flex items-center gap-1 text-sm font-medium link-info w-fit">' + Icon("chevron-left", "size-3-5") + " voltar para o sindicato</a>" +
      '<div class="flex items-center justify-between gap-3 flex-wrap" style="min-height:32px;">' +
      '<div class="flex flex-col gap-1">' + tituloHtml +
      '<span class="text-xs text-muted">Sindicato: <a class="link-info" href="sindicato.html?sindicato=' + encodeURIComponent(sindicatoVinculado.codigo) + '">' + sindicatoVinculado.nome + "</a>" + (form.codigo ? " · Código " + form.codigo : "") + "</span>" +
      "</div>" + acoesHtml + "</div></div>" +
      '<div class="tabs-list" style="overflow-x:auto;max-width:100%;">' + tabsHtml + "</div>" +
      '<div id="tab-panel" class="flex flex-col gap-3">' + TABS.find((t) => t.key === state.tab).render() + "</div>";

    wireEvents();
  }

  function wireEvents() {
    document.querySelectorAll("[data-tab]").forEach((el) => el.addEventListener("click", () => { state.tab = el.getAttribute("data-tab"); render(); }));

    const btnEditar = document.getElementById("btn-editar");
    if (btnEditar) btnEditar.addEventListener("click", () => { mode = "edit"; render(); });

    const btnCancelar = document.getElementById("btn-cancelar");
    if (btnCancelar) {
      btnCancelar.addEventListener("click", () => {
        if (isNovo) { window.location.href = "sindicato.html?sindicato=" + encodeURIComponent(sindicatoVinculado.codigo); return; }
        form = JSON.parse(JSON.stringify(convencaoExistente));
        mode = "view";
        render();
      });
    }

    const btnGravar = document.getElementById("btn-gravar");
    if (btnGravar) btnGravar.addEventListener("click", salvar);

    const inputDescricao = document.getElementById("input-descricao");
    if (inputDescricao) {
      inputDescricao.addEventListener("input", () => {
        form.descricao = inputDescricao.value;
        const btn = document.getElementById("btn-gravar");
        if (btn) btn.disabled = !camposObrigatoriosPreenchidos();
      });
    }

    document.querySelectorAll("input[data-path], textarea[data-path], select[data-path]").forEach((el) => {
      const evt = el.tagName === "SELECT" ? "change" : "change";
      el.addEventListener(evt, () => { setPath(form, el.getAttribute("data-path"), el.value); render(); });
    });
    document.querySelectorAll(".ucheckbox[data-path]").forEach((el) => {
      el.addEventListener("click", (e) => { e.preventDefault(); const p = el.getAttribute("data-path"); setPath(form, p, !getPath(form, p)); render(); });
    });
    document.querySelectorAll("[data-accordion-toggle]").forEach((btn) => {
      btn.addEventListener("click", () => { const k = btn.getAttribute("data-accordion-toggle"); state.accordionOpen[k] = !state.accordionOpen[k]; render(); });
    });

    // Empresas Vinculadas
    document.querySelectorAll("[data-empresa-check]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        const codigo = el.getAttribute("data-empresa-check");
        const idx = form.empresasVinculadas.indexOf(codigo);
        if (idx === -1) form.empresasVinculadas.push(codigo);
        else form.empresasVinculadas.splice(idx, 1);
        render();
      });
    });
    const btnTodas = document.getElementById("btn-emp-todas");
    if (btnTodas) btnTodas.addEventListener("click", () => { form.empresasVinculadas = E.EMPRESAS.map((e) => e.codigo); render(); });
    const btnNenhuma = document.getElementById("btn-emp-nenhuma");
    if (btnNenhuma) btnNenhuma.addEventListener("click", () => { form.empresasVinculadas = []; render(); });
    const btnInverter = document.getElementById("btn-emp-inverter");
    if (btnInverter) btnInverter.addEventListener("click", () => {
      const todas = E.EMPRESAS.map((e) => e.codigo);
      form.empresasVinculadas = todas.filter((c) => !form.empresasVinculadas.includes(c));
      render();
    });

    // Grade de configuração de Contribuição Assistencial (inline)
    const btnAddGradeContrib = document.getElementById("btn-add-grade-contrib");
    if (btnAddGradeContrib) btnAddGradeContrib.addEventListener("click", () => { form.contribuicoes.gradeConfiguracaoContribAssistencial.push({ faixa: "", percentual: "", valorFixo: "" }); render(); });
    document.querySelectorAll("[data-grade-contrib]").forEach((el) => {
      el.addEventListener("change", () => {
        const i = Number(el.getAttribute("data-grade-contrib"));
        form.contribuicoes.gradeConfiguracaoContribAssistencial[i][el.getAttribute("data-campo")] = el.value;
      });
    });
    document.querySelectorAll("[data-remove-grade-contrib]").forEach((el) => {
      el.addEventListener("click", () => { form.contribuicoes.gradeConfiguracaoContribAssistencial.splice(Number(el.getAttribute("data-remove-grade-contrib")), 1); render(); });
    });

    // Grade de Adicional por Tempo de Serviço (inline)
    const btnAddGradeTempo = document.getElementById("btn-add-grade-tempo-servico");
    if (btnAddGradeTempo) btnAddGradeTempo.addEventListener("click", () => { form.condicionais.calculos.adicionalTempoServico.grade.push({ periodicidade: "", percentual: "", base: "" }); render(); });
    document.querySelectorAll("[data-grade-tempo-servico]").forEach((el) => {
      el.addEventListener("change", () => {
        const i = Number(el.getAttribute("data-grade-tempo-servico"));
        form.condicionais.calculos.adicionalTempoServico.grade[i][el.getAttribute("data-campo")] = el.value;
      });
    });
    document.querySelectorAll("[data-remove-grade-tempo-servico]").forEach((el) => {
      el.addEventListener("click", () => { form.condicionais.calculos.adicionalTempoServico.grade.splice(Number(el.getAttribute("data-remove-grade-tempo-servico")), 1); render(); });
    });

    // Piso Salarial
    const btnAddPiso = document.getElementById("btn-add-piso");
    if (btnAddPiso) btnAddPiso.addEventListener("click", () => abrirPiso(null));
    document.querySelectorAll("[data-editar-piso]").forEach((el) => el.addEventListener("click", () => abrirPiso(el.getAttribute("data-editar-piso"))));
    document.querySelectorAll("[data-remover-piso]").forEach((el) => el.addEventListener("click", () => confirmarRemoverPiso(el.getAttribute("data-remover-piso"))));

    // Histórico
    const btnAddHist = document.getElementById("btn-add-historico");
    if (btnAddHist) btnAddHist.addEventListener("click", () => abrirHistorico(null));
    document.querySelectorAll("[data-editar-historico]").forEach((el) => el.addEventListener("click", () => abrirHistorico(el.getAttribute("data-editar-historico"))));
    document.querySelectorAll("[data-remover-historico]").forEach((el) => el.addEventListener("click", () => confirmarRemoverHistorico(el.getAttribute("data-remover-historico"))));
  }

  function salvar() {
    const lista = D.getConvencoes();
    if (isNovo) {
      form.codigo = D.proximoCodigo(lista, "CONV");
      D.setConvencoes(lista.concat([form]));
      window.location.href = "convencao.html?convencao=" + encodeURIComponent(form.codigo) + "&sindicato=" + encodeURIComponent(sindicatoVinculado.codigo) + "&criado=1";
      return;
    }
    const atualizados = lista.map((c) => (c.codigo === form.codigo ? JSON.parse(JSON.stringify(form)) : c));
    D.setConvencoes(atualizados);
    Object.assign(convencaoExistente, JSON.parse(JSON.stringify(form)));
    mode = "view";
    render();
    UI.showToast("Convenção salva", form.descricao + " foi atualizada com sucesso.");
  }

  // ===== Sheet: Piso Salarial =====
  let pisoEditandoCodigo = null;
  function abrirPiso(codigo) {
    pisoEditandoCodigo = codigo;
    const piso = codigo ? form.pisoSalarial.find((p) => p.codigo === codigo) : null;
    document.getElementById("piso-title").textContent = piso ? "Editar piso salarial" : "Adicionar piso salarial";
    document.getElementById("piso-descricao").value = piso ? piso.descricao : "";
    document.getElementById("piso-valor").value = piso ? piso.valor : "";
    atualizarBotaoPiso();
    UI.openSheet(document.getElementById("piso-overlay"), document.getElementById("piso-panel"));
  }
  function atualizarBotaoPiso() {
    const ok = document.getElementById("piso-descricao").value.trim() && document.getElementById("piso-valor").value.trim();
    document.getElementById("piso-salvar").disabled = !ok;
  }
  function fecharPiso() { UI.closeSheet(document.getElementById("piso-overlay"), document.getElementById("piso-panel")); }
  function salvarPiso() {
    const descricao = document.getElementById("piso-descricao").value.trim();
    const valor = document.getElementById("piso-valor").value.trim();
    if (!descricao || !valor) return;
    if (pisoEditandoCodigo) {
      form.pisoSalarial = form.pisoSalarial.map((p) => (p.codigo === pisoEditandoCodigo ? { codigo: p.codigo, descricao, valor } : p));
    } else {
      form.pisoSalarial.push({ codigo: D.proximoCodigo(form.pisoSalarial, "PISO"), descricao, valor });
    }
    fecharPiso();
    render();
  }
  let pisoRemovendoCodigo = null;
  function confirmarRemoverPiso(codigo) {
    pisoRemovendoCodigo = codigo;
    const piso = form.pisoSalarial.find((p) => p.codigo === codigo);
    document.getElementById("piso-delete-description").textContent = 'O piso "' + piso.descricao + '" será removido desta convenção.';
    UI.openDialog(document.getElementById("piso-delete-overlay"));
  }
  function removerPiso() {
    form.pisoSalarial = form.pisoSalarial.filter((p) => p.codigo !== pisoRemovendoCodigo);
    UI.closeDialog(document.getElementById("piso-delete-overlay"));
    render();
  }

  // ===== Sheet: Histórico de Alteração Salarial =====
  let histPicker = null;
  let histDataAtual = "";
  let histEditandoChave = null;
  function chaveHistorico(h) { return h.data + "|" + h.descricao.replace(/"/g, ""); }
  function abrirHistorico(chave) {
    histEditandoChave = chave;
    const h = chave ? form.historico.find((x) => chaveHistorico(x) === chave) : null;
    document.getElementById("hist-title").textContent = h ? "Editar registro do histórico" : "Registrar alteração salarial";
    document.getElementById("hist-descricao").value = h ? h.descricao : "";
    document.getElementById("hist-tipo").value = h ? h.tipo : "";
    document.getElementById("hist-processo").value = h ? h.numeroProcesso || "" : "";
    document.getElementById("hist-percentual").value = h ? h.percentualCCT || "" : "";
    histDataAtual = h ? h.data : "";
    histPicker.setValue(histDataAtual);
    atualizarCampoProcesso();
    atualizarBotaoHistorico();
    UI.openSheet(document.getElementById("hist-overlay"), document.getElementById("hist-panel"));
  }
  function atualizarCampoProcesso() {
    const tipo = document.getElementById("hist-tipo").value;
    document.getElementById("hist-processo-field").style.display = tipo && tipo !== "Convenção Coletiva" ? "" : "none";
  }
  function atualizarBotaoHistorico() {
    const ok = histDataAtual && document.getElementById("hist-descricao").value.trim() && document.getElementById("hist-tipo").value;
    document.getElementById("hist-salvar").disabled = !ok;
  }
  function fecharHistorico() { UI.closeSheet(document.getElementById("hist-overlay"), document.getElementById("hist-panel")); }
  function salvarHistorico() {
    const descricao = document.getElementById("hist-descricao").value.trim();
    const tipo = document.getElementById("hist-tipo").value;
    if (!histDataAtual || !descricao || !tipo) return;
    const registro = { data: histDataAtual, descricao, tipo, numeroProcesso: document.getElementById("hist-processo").value.trim(), percentualCCT: document.getElementById("hist-percentual").value.trim() };
    if (histEditandoChave) {
      form.historico = form.historico.map((h) => (chaveHistorico(h) === histEditandoChave ? registro : h));
    } else {
      form.historico.push(registro);
    }
    fecharHistorico();
    render();
  }
  let histRemovendoChave = null;
  function confirmarRemoverHistorico(chave) {
    histRemovendoChave = chave;
    const h = form.historico.find((x) => chaveHistorico(x) === chave);
    document.getElementById("hist-delete-description").textContent = 'O registro "' + h.descricao + '" (' + h.data + ") será removido do histórico.";
    UI.openDialog(document.getElementById("hist-delete-overlay"));
  }
  function removerHistorico() {
    form.historico = form.historico.filter((h) => chaveHistorico(h) !== histRemovendoChave);
    UI.closeDialog(document.getElementById("hist-delete-overlay"));
    render();
  }

  Shell.mount(document.getElementById("shell-root"), {
    base: "../",
    active: "dp",
    crumbs: isNovo
      ? [{ label: "sindicatos", href: "index.html" }, { label: sindicatoVinculado.nome, href: "sindicato.html?sindicato=" + encodeURIComponent(sindicatoVinculado.codigo) }, { label: "nova convenção" }]
      : [{ label: "sindicatos", href: "index.html" }, { label: sindicatoVinculado.nome, href: "sindicato.html?sindicato=" + encodeURIComponent(sindicatoVinculado.codigo) }, { label: form.descricao }],
  });

  ensureToast();

  document.getElementById("piso-close").innerHTML = Icon("x", "size-4");
  document.getElementById("piso-delete-close").innerHTML = Icon("x", "size-4");
  document.getElementById("hist-close").innerHTML = Icon("x", "size-4");
  document.getElementById("hist-delete-close").innerHTML = Icon("x", "size-4");
  document.querySelector("#hist-data-picker .date-picker-icon").innerHTML = Icon("calendar", "size-4");
  document.querySelectorAll('#hist-data-picker .date-picker-nav-btn[data-nav="prev"]').forEach((el) => (el.innerHTML = Icon("chevron-left", "size-4")));
  document.querySelectorAll('#hist-data-picker .date-picker-nav-btn[data-nav="next"]').forEach((el) => (el.innerHTML = Icon("chevron-right", "size-4")));
  document.getElementById("hist-tipo").innerHTML = '<option value="">Selecione...</option>' + D.TIPO_HISTORICO_OPCOES.map((t) => '<option value="' + t + '">' + t + "</option>").join("");

  document.getElementById("piso-overlay").addEventListener("click", fecharPiso);
  document.getElementById("piso-close").addEventListener("click", fecharPiso);
  document.getElementById("piso-cancelar").addEventListener("click", fecharPiso);
  document.getElementById("piso-salvar").addEventListener("click", salvarPiso);
  document.getElementById("piso-descricao").addEventListener("input", atualizarBotaoPiso);
  document.getElementById("piso-valor").addEventListener("input", atualizarBotaoPiso);
  document.getElementById("piso-delete-close").addEventListener("click", () => UI.closeDialog(document.getElementById("piso-delete-overlay")));
  document.getElementById("piso-delete-cancel").addEventListener("click", () => UI.closeDialog(document.getElementById("piso-delete-overlay")));
  document.getElementById("piso-delete-confirm").addEventListener("click", removerPiso);

  document.getElementById("hist-overlay").addEventListener("click", fecharHistorico);
  document.getElementById("hist-close").addEventListener("click", fecharHistorico);
  document.getElementById("hist-cancelar").addEventListener("click", fecharHistorico);
  document.getElementById("hist-salvar").addEventListener("click", salvarHistorico);
  document.getElementById("hist-descricao").addEventListener("input", atualizarBotaoHistorico);
  document.getElementById("hist-tipo").addEventListener("change", () => { atualizarCampoProcesso(); atualizarBotaoHistorico(); });
  document.getElementById("hist-delete-close").addEventListener("click", () => UI.closeDialog(document.getElementById("hist-delete-overlay")));
  document.getElementById("hist-delete-cancel").addEventListener("click", () => UI.closeDialog(document.getElementById("hist-delete-overlay")));
  document.getElementById("hist-delete-confirm").addEventListener("click", removerHistorico);
  histPicker = UI.initDatePicker(document.getElementById("hist-data-picker"), (valor) => { histDataAtual = valor || ""; atualizarBotaoHistorico(); });

  render();

  if (D.getQueryParam("criado")) UI.showToast("Convenção criada", form.descricao + " foi cadastrada com sucesso.");
})();
